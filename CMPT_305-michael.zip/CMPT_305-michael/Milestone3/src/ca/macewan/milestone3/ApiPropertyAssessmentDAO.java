package ca.macewan.milestone3;

import java.util.List;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class ApiPropertyAssessmentDAO implements PropertyAssessmentDAO {
    private String endpoint = "https://data.edmonton.ca/resource/q7d6-ambg.csv";
    private HttpClient client = HttpClient.newHttpClient();
    private HttpRequest request;
    private HttpResponse<String> response;
    private String encoded;
    private String url;
    private String dataString;
    private String[] values;
    private String classOne;
    private Integer classOneP;
    private String classTwo;
    private Integer classTwoP;
    private String classThree;
    private Integer classThreeP;

    // Gets all property data from API
    @Override
    public List<PropertyAssessment> getAllProperty() {
        List<PropertyAssessment> allProperties = new ArrayList<>();
        request = HttpRequest.newBuilder().uri(URI.create(endpoint)).GET().build();

        try {
            response = client.send(request, HttpResponse.BodyHandlers.ofString());
            dataString = response.body();
            dataString = dataString.split("\n", 2)[1].replace("\"", "");
            String[] accountsList = dataString.split("\n");

            for (String accounts : accountsList) {
                values = accounts.split(",");
                PropertyAssessment accountData = accountProperty(values);
                allProperties.add(accountData);
            }
            return allProperties;

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Gets data by account number
    @Override
    public PropertyAssessment getByAccountNumber(Integer accountNumber) {
        url = endpoint + "?account_number=" + accountNumber;
        request = HttpRequest.newBuilder().uri(URI.create(url)).GET().build();

        try {
            response = client.send(request, HttpResponse.BodyHandlers.ofString());
            dataString = response.body();
            dataString = dataString.split("\n")[1].replace("\"", "");
            values = dataString.split(",");

            return accountProperty(values);

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Gets data by neighbourhood
    @Override
    public List<PropertyAssessment> getByNeighbourhood(String neighbourhood) {
        List<PropertyAssessment> neighbourhoodData = new ArrayList<>();

        encoded = URLEncoder.encode(neighbourhood.toUpperCase(), StandardCharsets.UTF_8);
        url = endpoint + "?neighbourhood=" + encoded;
        request = HttpRequest.newBuilder().uri(URI.create(url)).GET().build();

        try {
            response = client.send(request, HttpResponse.BodyHandlers.ofString());
            dataString = response.body();
            dataString = dataString.split("\n", 2)[1].replace("\"", "");
            String[] neighbourhoodList = dataString.split("\n");

            for (String accounts : neighbourhoodList) {
                values = accounts.split(",");
                PropertyAssessment accountData = accountProperty(values);
                neighbourhoodData.add(accountData);
            }
            return neighbourhoodData;

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Gets data by assessment class
    @Override
    public List<PropertyAssessment> getByAssessmentClass(String assessmentClass) {
        List<PropertyAssessment> classData = new ArrayList<>();

        encoded = URLEncoder.encode(assessmentClass.toUpperCase(), StandardCharsets.UTF_8);

        try {
            String url1 = endpoint + "?mill_class_1=" + encoded;
            HttpRequest request1 = HttpRequest.newBuilder().uri(URI.create(url1)).GET().build();
            HttpResponse<String> response1 = client.send(request1, HttpResponse.BodyHandlers.ofString());
            List<PropertyAssessment> classOneData = assessmentClassData(response1.body());

            String url2 = endpoint + "?mill_class_2=" + encoded;
            HttpRequest request2 = HttpRequest.newBuilder().uri(URI.create(url2)).GET().build();
            HttpResponse<String> response2 = client.send(request2, HttpResponse.BodyHandlers.ofString());
            List<PropertyAssessment> classTwoData = assessmentClassData(response2.body());

            String url3 = endpoint + "?mill_class_3=" + encoded;
            HttpRequest request3 = HttpRequest.newBuilder().uri(URI.create(url3)).GET().build();
            HttpResponse<String> response3 = client.send(request1, HttpResponse.BodyHandlers.ofString());
            List<PropertyAssessment> classThreeData = assessmentClassData(response3.body());

            classData.addAll(classOneData);
            classData.addAll(classTwoData);
            classData.addAll(classThreeData);

            return classData;
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Gets data by address
    @Override
    public List<PropertyAssessment> getByAddress(String address) {
        List<PropertyAssessment> allProperties = getAllProperty();

        List<PropertyAssessment> addressData = new ArrayList<>();
        for (PropertyAssessment account : allProperties) {
            String fullAddress = account.getAccountAddress().toString();
            if (fullAddress.contains(address))
                addressData.add(account);
        }
        return addressData;
    }

    // Gets data by assessed value range
    @Override
    public List<PropertyAssessment> getByRange(Integer min, Integer max) {
        List<PropertyAssessment> allProperties = getAllProperty();

        List<PropertyAssessment> rangeData = new ArrayList<>();
        for (PropertyAssessment account : allProperties) {
            if (account.getAssessedValue() > min && max == 0)
                rangeData.add(account);
            else if (account.getAssessedValue() < max && min == 0)
                rangeData.add(account);
            else if (account.getAssessedValue() > min && account.getAssessedValue() < max)
                rangeData.add(account);
        }
        return rangeData;
    }

    // Parses data into proper datatype to create PropertyAssessment object
    public PropertyAssessment accountProperty(String[] values) {
        if (values.length == 16) {
            classOne = values[15]; classOneP = makeInt(values[12]);
            classTwo = null; classTwoP = null;
            classThree = null; classThreeP = null;
        }
        else if (values.length == 17) {
            classOne = values[15]; classOneP = makeInt(values[12]);
            classTwo = values[16]; classTwoP = makeInt(values[13]);
            classThree = null; classThreeP = null;
        }
        else {
            classOne = values[15]; classOneP = makeInt(values[12]);
            classTwo = values[16]; classTwoP = makeInt(values[13]);
            classThree = values[17]; classThreeP = makeInt(values[14]);
        }
        return new PropertyAssessment(makeInt(values[0]),
                makeString(values[1]), makeInt(values[2]), makeString(values[3]),
                makeString(values[4]),
                makeInt(values[5]), makeString(values[6]), makeString(values[7]),
                makeInt(values[8]),
                makeFloat(values[9]), makeFloat(values[10]),
                classOne, classOneP, classTwo, classTwoP, classThree, classThreeP);
    }

    // Function to help split each url into list of PropertyAssessment objects
    public List<PropertyAssessment> assessmentClassData(String response) {
        List<PropertyAssessment> classData = new ArrayList<>();
        response = response.split("\n", 2)[1].replace("\"", "");
        String[] classList = response.split("\n");

        for (String accounts : classList) {
            values = accounts.split(",");
            PropertyAssessment accountData = accountProperty(values);

            classData.add(accountData);
        }
        return classData;
    }

    // Ensures proper datatype is passed into PropertyAssessment Object
    public static String makeString(String value) {
        if (!value.isEmpty())
            return value;
        return null;
    }
    public static Integer makeInt(String value) {
        if (!value.isEmpty())
            return Integer.parseInt(value);
        return null;
    }
    public static Float makeFloat(String value) {
        if (!value.isEmpty())
            return Float.parseFloat(value);
        return null;
    }
}
