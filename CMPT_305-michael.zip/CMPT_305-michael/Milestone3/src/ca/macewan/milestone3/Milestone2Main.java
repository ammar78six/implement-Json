package ca.macewan.milestone3;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.util.List;
public class Milestone2Main extends Application {
    private PropertyAssessmentDAO CSVDao = new CsvPropertyAssessmentDAO();
    private PropertyAssessmentDAO APIDao = new ApiPropertyAssessmentDAO();
    private TableView<PropertyAssessment> table = new TableView<>();
    private VBox vBox = new VBox(10);
    private VBox newVBox = new VBox(10);
    private ObservableList<PropertyAssessment> properties;
    private ComboBox sourceOptions;
    private ComboBox assessmentOptions;
    private Button search;
    private TextField accountNumberField;
    private TextField neighbourhoodField;
    private TextField addressField;
    private TextField minField;
    private TextField maxField;

    public static void main(String[] args) {
        launch(args);
    }

    public void start(Stage primaryStage) {
        primaryStage.setTitle("Edmonton Property Assessments");

        BorderPane bPane = new BorderPane();
        Scene scene = new Scene(bPane, 1920, 1080);

        primaryStage.setScene(scene);
        // Window title (Top)
        setWindowTitle(bPane);

        // Table data (Center)
        setNullTable(); // Sets empty TableView
        bPane.setCenter(table);
        BorderPane.setMargin(table, new Insets(10, 10, 10, 10));

        // Search pane (Left)
        configureSearchWindow();
        bPane.setLeft(vBox);
        vBox.setPrefWidth(300);
        BorderPane.setMargin(vBox, new Insets(10, 10, 10, 10));
        String cssLayout = "-fx-border-color: gray;\n" +
                           "-fx-border-width: 0.5;\n";
        vBox.setStyle(cssLayout);

        primaryStage.show();
    }

    public void setWindowTitle(BorderPane bPane) {
        Label windowTitle = new Label("Edmonton Property Assessment (2022)");
        windowTitle.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        bPane.setTop(windowTitle);
        BorderPane.setMargin(windowTitle, new Insets(10, 0, 0, 10));
    }

    public void setNullTable() {
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);

        List<PropertyAssessment> nullProperties
                = FXCollections.observableArrayList(new PropertyAssessment(null, // Account number
                null, null, null, // Address
                null, // Garage
                null, null, null, // Neighbourhood
                null, // Assessed value
                null, null, // Location
                null, null, // Assessment class
                null, null,
                null, null));

        table.setItems(properties);
        // Set TableView columns
        TableColumn<PropertyAssessment, Integer> accountCol
                = new TableColumn<>("Account");
        accountCol.setCellValueFactory(new PropertyValueFactory<>("accountNumber"));

        TableColumn<PropertyAssessment, String> addressCol
                = new TableColumn<>("Address");
        addressCol.setCellValueFactory(new PropertyValueFactory<>("accountAddress"));

        TableColumn<PropertyAssessment, Integer> assessedValueCol
                = new TableColumn<>("Assessed Value");
        assessedValueCol.setCellValueFactory(new PropertyValueFactory<>("assessedValueString"));

        TableColumn<PropertyAssessment, String> assessmentClassCol
                = new TableColumn<>("Assessment Class");
        assessmentClassCol.setCellValueFactory(new PropertyValueFactory<>("assessmentClass"));

        TableColumn<PropertyAssessment, String> neighbourhoodCol
                = new TableColumn<>("Neighbourhood");
        neighbourhoodCol.setCellValueFactory(new PropertyValueFactory<>("accountNeighbourhood"));

        TableColumn<PropertyAssessment, String> locationCol
                = new TableColumn<>("(Latitude, Longitude)");
        locationCol.setCellValueFactory(new PropertyValueFactory<>("location"));
        table.getColumns().addAll(accountCol, addressCol,
                assessedValueCol, assessmentClassCol,
                neighbourhoodCol, locationCol);
    }
    // Updates TableView with CSV data
    public void configureCSVTable() {
        PropertyAssessmentDAO propertyData = new CsvPropertyAssessmentDAO();
        List<PropertyAssessment> allProperty = propertyData.getAllProperty();
        updateTableView(allProperty);
    }
    // Updates TableView with API data
    public void configureAPITable() {
        PropertyAssessmentDAO propertyAPIData = new ApiPropertyAssessmentDAO();
        List<PropertyAssessment> allAPIProperty = propertyAPIData.getAllProperty();
        updateTableView(allAPIProperty);
    }
    // Creation of VBox within VBox, this was done because I could not adjust
    // width the way I wanted to
    public void configureSearchWindow() {
        newVBox.setPrefWidth(280);
        newVBox.setPrefHeight(800);
        newVBox.setPadding(new Insets(0, 10, 0, 10));
        vBox.getChildren().add(newVBox);
        searchBox();
    }

    // Item creations for search Pane
    public void searchBox() {
        Label sourceTitle = new Label("Select Data Source");
        sourceTitle.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        sourceTitle.setPadding(new Insets(10, 0, 0, 0));
        // Combobox for choosing source data
        ObservableList<String> options
                = FXCollections.observableArrayList(
                "CSV File",
                "Edmonton's Open Data Portal");
        sourceOptions = new ComboBox(options);
        sourceOptions.setPrefWidth(280);
        // Button to select source data
        Button readData = new Button("Read Data");
        readData.setOnAction(event -> {
            readDataSelection(sourceOptions.getValue().toString());
        });
        readData.setPrefWidth(280);

        Label propertyTitle = new Label("Find Property Assessment");
        propertyTitle.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        propertyTitle.setPadding(new Insets(10, 0, 0, 0));

        Label accountNumber = new Label("Account Number:");
        accountNumber.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        accountNumberField = new TextField();

        Label address = new Label("Address (#suite #house street):");
        address.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        addressField = new TextField();

        Label neighbourhood = new Label("Neighbourhood:");
        neighbourhood.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        neighbourhoodField = new TextField();

        Label assessment = new Label("Assessment Class:");
        assessment.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        // Combobox for choosing assessment class
        ObservableList<String> classOptions
                = FXCollections.observableArrayList(
                "",
                "RESIDENTIAL",
                "OTHER RESIDENTIAL",
                "COMMERCIAL","FARMLAND");
        assessmentOptions = new ComboBox(classOptions);
        assessmentOptions.setPrefWidth(280);

        Label valueRange = new Label("Assessed Value Range:");
        valueRange.setFont(Font.font("Arial", FontWeight.NORMAL, 14));

        HBox minMax = new HBox();
        minField = new TextField();
        maxField = new TextField();
        minField.setPromptText("Min Value");
        maxField.setPromptText("Max Value");
        minMax.setSpacing(10);
        minMax.getChildren().addAll(minField, maxField);
        // Search button
        HBox searchReset = new HBox();
        search = new Button("Search");
        search.setPrefWidth(135);
        search.setOnAction(event -> {
            readSearchSelection();
        });
        // Reset button
        Button reset = new Button("Reset");
        reset.setOnAction(event -> {accountNumberField.clear();
            addressField.clear();
            neighbourhoodField.clear();
            assessmentOptions.getSelectionModel()
                    .clearSelection();
            minField.clear();
            maxField.clear();
            readDataSelection(sourceOptions
                    .getValue()
                    .toString());
        });
        reset.setPrefWidth(135);
        searchReset.setSpacing(10);

        searchReset.getChildren().addAll(search, reset);

        newVBox.getChildren().addAll(sourceTitle, sourceOptions, readData,
                propertyTitle, accountNumber, accountNumberField,
                address, addressField, neighbourhood, neighbourhoodField,
                assessment, assessmentOptions, valueRange, minMax, searchReset);
    }
    // A super nester of if statements to check search parameters one at a time
    private void readSearchSelection() {
        if (accountNumberField.getText().equals(""))
            if (addressField.getText().equals(""))
                if (neighbourhoodField.getText().equals(""))
                    if (minField.getText().equals("") && maxField.getText().equals(""))
                        if (assessmentOptions.getValue() == null
                                || assessmentOptions.getValue().toString().equals(""))
                            errorEmpty();
                        else
                            searchByAssessment(sourceOptions.getValue().toString());
                    else
                        searchByValue(sourceOptions.getValue().toString());
                else
                    searchByNeighbourhood(sourceOptions.getValue().toString());
            else
                searchbyAddress(sourceOptions.getValue().toString());
        else
            searchByAccount(sourceOptions.getValue().toString());
    }
    // Reads from selected data source
    private void readDataSelection(String dataSelection) {
        if (dataSelection.equals("CSV File"))
            configureCSVTable();
        else if (dataSelection.equals("Edmonton's Open Data Portal"))
            configureAPITable();
    }
    // Searches by account number
    private void searchByAccount(String sourceSelection) {
        PropertyAssessment accountProperty;
        try {
            List<PropertyAssessment> accountDetails;
            if (sourceSelection.equals("CSV File")) {
                accountProperty = CSVDao.getByAccountNumber(Integer
                        .parseInt(accountNumberField.getText()));
                accountDetails = FXCollections
                        .observableArrayList(accountProperty);
            } else {
                accountProperty = APIDao.getByAccountNumber(Integer
                        .parseInt(accountNumberField.getText()));
                accountDetails = FXCollections
                        .observableArrayList(accountProperty);
            }
            updateTableView(accountDetails);
        } catch (NumberFormatException e) {
            errorSearch();
        }
    }
    // Searches by address
    private void searchbyAddress(String sourceSelection) {
        List<PropertyAssessment> allProperty;
        try {
            if (sourceSelection.equals("CSV File"))
                allProperty = CSVDao.getByAddress(addressField
                        .getText()
                        .toUpperCase());
            else
                allProperty = APIDao.getByAddress(addressField
                        .getText()
                        .toUpperCase());
            updateTableView(allProperty);
        } catch (Exception e) {
            errorSearch();
        }
    }
    // Searches by neighbourhood
    private void searchByNeighbourhood(String sourceSelection) {
        List<PropertyAssessment> allProperty;
        try {
            if (sourceSelection.equals("CSV File"))
                allProperty = CSVDao.getByNeighbourhood(neighbourhoodField
                        .getText()
                        .toUpperCase());
            else
                allProperty = APIDao.getByNeighbourhood(neighbourhoodField
                        .getText()
                        .toUpperCase());
            updateTableView(allProperty);
        } catch (Exception e) {
            errorSearch();
        }
    }
    // Searches by assessment classes
    private void searchByAssessment(String sourceSelection) {
        List<PropertyAssessment> allProperty;
        try {
            if (sourceSelection.equals("CSV File"))
                allProperty = CSVDao.getByAssessmentClass(assessmentOptions
                        .getValue()
                        .toString()
                        .toUpperCase());
            else
                allProperty = APIDao.getByAssessmentClass(assessmentOptions
                        .getValue()
                        .toString()
                        .toUpperCase());
            updateTableView(allProperty);
        } catch (Exception e) {
            errorSearch();
        }
    }
    // Searches by assessed value
    private void searchByValue(String sourceSelection) {
        List<PropertyAssessment> allProperty;
        try {
            if (sourceSelection.equals("CSV File"))
                if (minField.getText().equals(""))
                    allProperty= CSVDao.getByRange(0, Integer.parseInt(maxField.getText()));
                else if (maxField.getText().equals(""))
                    allProperty = CSVDao.getByRange(Integer.parseInt(minField.getText()), 0);
                else
                    allProperty = CSVDao.getByRange(Integer.parseInt(minField.getText()),
                            Integer.parseInt(maxField.getText()));
            else
            if (minField.getText().equals(""))
                allProperty = APIDao.getByRange(0, Integer.parseInt(maxField.getText()));
            else if (maxField.getText().equals(""))
                allProperty = APIDao.getByRange(Integer.parseInt(minField.getText()), 0);
            else
                allProperty = APIDao.getByRange(Integer.parseInt(minField.getText()),
                        Integer.parseInt(maxField.getText()));
            updateTableView(allProperty);
        } catch (Exception e) {
            errorSearch();
        }
    }
    // Populates TableView and updates accordingly
    private void updateTableView(List<PropertyAssessment> updatedList) {
        properties = FXCollections.observableArrayList(updatedList);
        table.setItems(properties);

        TableColumn<PropertyAssessment, Integer> accountCol
                = new TableColumn<>("Account");
        accountCol.setCellValueFactory(new PropertyValueFactory<>("accountNumber"));

        TableColumn<PropertyAssessment, String> addressCol
                = new TableColumn<>("Address");
        addressCol.setCellValueFactory(new PropertyValueFactory<>("accountAddress"));

        TableColumn<PropertyAssessment, Integer> assessedValueCol
                = new TableColumn<>("Assessed Value");
        assessedValueCol.setCellValueFactory(new PropertyValueFactory<>("assessedValueString"));

        TableColumn<PropertyAssessment, String> assessmentClassCol
                = new TableColumn<>("Assessment Class");
        assessmentClassCol.setCellValueFactory(new PropertyValueFactory<>("assessmentClass"));

        TableColumn<PropertyAssessment, String> neighbourhoodCol
                = new TableColumn<>("Neighbourhood");
        neighbourhoodCol.setCellValueFactory(new PropertyValueFactory<>("accountNeighbourhood"));

        TableColumn<PropertyAssessment, String> locationCol
                = new TableColumn<>("(Latitude, Longitude)");
        locationCol.setCellValueFactory(new PropertyValueFactory<>("location"));
    }
    // Error window when search does not find anything
    public void errorSearch() {
        Alert errorSearchWindow = new Alert(Alert.AlertType.INFORMATION);
        errorSearchWindow.setTitle("Search Results");
        errorSearchWindow.setHeaderText("Oops, did not find anything!");
        errorSearchWindow.setContentText("Please input valid search.");
        errorSearchWindow.showAndWait();
    }
    // Error window when all search parameters are empty
    public void errorEmpty() {
        Alert errorEmptySearch = new Alert(Alert.AlertType.INFORMATION);
        errorEmptySearch.setTitle("Search Results");
        errorEmptySearch.setHeaderText("Oops, did not input any search parameters!");
        errorEmptySearch.setContentText("Please input valid search.");
        errorEmptySearch.showAndWait();
    }
}
