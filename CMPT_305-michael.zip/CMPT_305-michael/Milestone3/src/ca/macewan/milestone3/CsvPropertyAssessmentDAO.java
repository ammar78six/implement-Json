package ca.macewan.milestone3;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
public class CsvPropertyAssessmentDAO implements PropertyAssessmentDAO {
    PropertyAssessments properties = new PropertyAssessments();
    List<PropertyAssessment> allProperties = properties.getPropertyData("Property_Assessment_Data_2022.csv");
    @Override
    public List<PropertyAssessment> getAllProperty() {
        return allProperties;
    }

    // Gets data for account number
    @Override
    public PropertyAssessment getByAccountNumber(Integer accountNumber) {
        for (PropertyAssessment account : allProperties) {
            if (account.getAccountNumber().equals(accountNumber))
                return account;
        }
        return null;
    }

    // Gets data for neighbourhood
    @Override
    public List<PropertyAssessment> getByNeighbourhood(String neighbourhood) {
        List<PropertyAssessment> neighbourhoodData = new ArrayList<>();

        for (PropertyAssessment account : allProperties) {
            String fullNeighbourhood = account.getAccountNeighbourhood().toString();

            if (fullNeighbourhood.contains(neighbourhood))
                neighbourhoodData.add(account);
        }
        return neighbourhoodData;
    }

    // Gets data for assessment class
    @Override
    public List<PropertyAssessment> getByAssessmentClass(String assessmentClass) {
        List<PropertyAssessment> assessmentClassData = new ArrayList<>();

        for (PropertyAssessment account : allProperties) {
            if (assessmentClass.toUpperCase().equals(account.getAssessmentClass().getClassOne())
            ||  assessmentClass.toUpperCase().equals(account.getAssessmentClass().getClassTwo())
            ||  assessmentClass.toUpperCase().equals(account.getAssessmentClass().getClassThree()))
                assessmentClassData.add(account);
        }
        return assessmentClassData;
    }

    // Gets data by address
    @Override
    public List<PropertyAssessment> getByAddress(String address) {
        List<PropertyAssessment> addressData = new ArrayList<>();

        for (PropertyAssessment account : allProperties) {
            String fullAddress = account.getAccountAddress().toString();

            if (fullAddress.contains(address)) {
                addressData.add(account);
            }
        }
        return addressData;
    }

    // Gets data by assessed value range
    @Override
    public List<PropertyAssessment> getByRange(Integer min, Integer max) {
        List<PropertyAssessment> rangeData = new ArrayList<>();

        for (PropertyAssessment account : allProperties) {
            if (account.getAssessedValue() > min && max == 0)
                rangeData.add(account);
            else if (account.getAssessedValue() < max && min == 0)
                rangeData.add(account);
            else if (account.getAssessedValue() > min && account.getAssessedValue() < max)
                rangeData.add(account);
        }
        return rangeData;
    }
}
