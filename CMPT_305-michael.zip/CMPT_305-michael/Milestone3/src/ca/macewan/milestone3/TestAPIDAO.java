package ca.macewan.milestone3;

import java.util.List;

public class TestAPIDAO {
    static PropertyAssessmentDAO demo = new ApiPropertyAssessmentDAO();
    public static void main(String[] args) {
        // List<PropertyAssessment> allData = demo.getAllProperty();
        // System.out.println(allData);

        // PropertyAssessment accountData = demo.getByAccountNumber(1200039);
        // System.out.println(accountData);

        //List<PropertyAssessment> neighbourhoodData = demo.getByNeighbourhood("granville");
        //System.out.println(neighbourhoodData);

        // List<PropertyAssessment> classData = demo.getByAssessmentClass("residential");
        // System.out.println(classData);

        // List<PropertyAssessment> addressData = demo.getByAddress("95 avenue");
        // System.out.println(addressData);

        // List<PropertyAssessment> rangeData = demo.getByRange(5000000, 0);
        // System.out.println(rangeData);
    }
}
