package ca.macewan.milestone3;

public class TestCSVDAO {
    static PropertyAssessmentDAO demo = new CsvPropertyAssessmentDAO();
    public static void main(String[] args) {
        // Uncomment to test

        // List<PropertyAssessment> allProperty = demo.getAllProperty();
        // System.out.println(allProperty);

        // PropertyAssessment accountData = demo.getByAccountNumber(1103530);
        // System.out.println(accountData);

        // List<PropertyAssessment> neighbourhoodData = demo.getByNeighbourhood("Belle Rive");
        // System.out.println(neighbourhoodData);

        // List<PropertyAssessment> classData = demo.getByAssessmentClass("RESIDENTIAL");
        // System.out.println(classData);

        // List<PropertyAssessment> neighbourhoodData = demo.getByNeighbourhood("93 avenue nw");
        // System.out.println(neighbourhoodData);

        // List<PropertyAssessment> valueData = demo.getByRange(70000, 100000);
        // System.out.println(valueData);

        // List<PropertyAssessment> valueData2 = demo.getByRange(70000, 0);
        // System.out.println(valueData2);

        // List<PropertyAssessment> valueData3 = demo.getByRange(0, 70000);
        // System.out.println(valueData3);
    }
}
