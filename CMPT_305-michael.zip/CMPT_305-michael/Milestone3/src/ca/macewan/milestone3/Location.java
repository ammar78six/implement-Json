package ca.macewan.milestone3;

public class Location {
    private Float latitude;
    private Float longitude;

    public Location(Float latitude, Float longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    // Returns latitude
    public Float getLatitude() {
        return latitude;
    }

    // Returns longitude
    public Float getLongitude() {
        return longitude;
    }

    // Converts location as string: (latitude, longitude)
    public String toString() {
        return "(" + latitude + ", " + longitude + ")";
    }
}
