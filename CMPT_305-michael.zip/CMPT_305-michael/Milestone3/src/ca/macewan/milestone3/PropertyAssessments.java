package ca.macewan.milestone3;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class PropertyAssessments {
    private List<PropertyAssessment> allAccountsData = new ArrayList<>();

    // Goes through CSV file and parses account values into PropertyAssessment objects
    public List<PropertyAssessment> getPropertyData(String csvFilename) {
        try {
            BufferedReader reader = Files.newBufferedReader(Paths.get(csvFilename));
            reader.readLine();

            String classOne; Integer classOneP;
            String classTwo; Integer classTwoP;
            String classThree; Integer classThreeP;

            String line;

            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");

                // Determines length of CSV index to set values for assessment classes
                if (values.length == 16) {
                    classOne = values[15]; classOneP = makeInt(values[12]);
                    classTwo = null; classTwoP = null;
                    classThree = null; classThreeP = null;
                }
                else if (values.length == 17) {
                    classOne = values[15]; classOneP = makeInt(values[12]);
                    classTwo = values[16]; classTwoP = makeInt(values[13]);
                    classThree = null; classThreeP = null;
                }
                else {
                    classOne = values[15]; classOneP = makeInt(values[12]);
                    classTwo = values[16]; classTwoP = makeInt(values[13]);
                    classThree = values[17]; classThreeP = makeInt(values[14]);
                }

                // Creates PropertyAssessment object to be filled into all accounts data
                PropertyAssessment accountData
                        = new PropertyAssessment(makeInt(values[0]),
                        makeString(values[1]), makeInt(values[2]), makeString(values[3]),
                        makeString(values[4]),
                        makeInt(values[5]), makeString(values[6]), makeString(values[7]),
                        makeInt(values[8]),
                        makeFloat(values[9]), makeFloat(values[10]),
                        classOne, classOneP, classTwo, classTwoP, classThree, classThreeP);
                // Stores all accounts as PropertyAssessment objects to list
                allAccountsData.add(accountData);
            }
        } catch (IOException e) {
            System.out.println("Error: can't open file " + csvFilename);
            System.exit(0);
        }
        return allAccountsData;
    }

    /* All make(String/Int/Float) functions ensures proper data is passed to
     * PropertyAssessment object.
     * If the value is not empty it will convert to proper datatype,
     * else as null
     */
    public static String makeString(String value) {
        if (!value.isEmpty())
            return value;
        return null;
    }
    public static Integer makeInt(String value) {
        if (!value.isEmpty())
            return Integer.parseInt(value);
        return null;
    }
    public static Float makeFloat(String value) {
        if (!value.isEmpty())
            return Float.parseFloat(value);
        return null;
    }

    // Returns all account data
    public List<PropertyAssessment> getAllAccountsData() {
        return allAccountsData;
    }

    // Implement methods as we need them, since I'm not sure how we'll be storing our data
}
