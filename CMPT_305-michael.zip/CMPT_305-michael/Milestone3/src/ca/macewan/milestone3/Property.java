package ca.macewan.milestone3;

public class Property {
    private Integer account;
    private String address;
    private Integer assessedValue;
    private String assessmentClass;
    private String neighbourhood;
    private String location;

    public Property(Integer account, String address, Integer assessedValue,
                    String assessmentClass, String neighbourhood, String location) {
        this.account = account;
        this.address = address;
        this.assessedValue = assessedValue;
        this.assessmentClass = assessmentClass;
        this.neighbourhood = neighbourhood;
        this.location = location;
    }

    // Returns account
    public Integer getAccount() {
        return account;
    }

    // Returns address
    public String getAddress() {
        return address;
    }

    // Returns assessed value
    public Integer getAssessedValue() {
        return assessedValue;
    }

    // Returns assessment classes
    public String getAssessmentClass() {
        return assessmentClass;
    }

    // Returns neighbourhood
    public String getNeighbourhood() {
        return neighbourhood;
    }

    // Returns location
    public String getLocation() {
        return location;
    }
}
