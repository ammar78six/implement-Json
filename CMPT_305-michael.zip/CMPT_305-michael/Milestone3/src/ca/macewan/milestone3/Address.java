package ca.macewan.milestone3;

public class Address {
    private String suite;
    private Integer houseNumber;
    private String streetName;

    public Address(String suite, Integer houseNumber, String streetName) {
        this.suite = suite;
        this.houseNumber = houseNumber;
        this.streetName = streetName;
    }

    // Returns suite
    public String getSuite() {
        return suite;
    }

    // Returns house number
    public Integer getHouseNumber() {
        return houseNumber;
    }

    // Returns street name
    public String getStreetName() {
        return streetName;
    }

    /* Converts address as string:
     *      Suite: 1007
     *      House number: 10145
     *      Street name: 121 STREET NW
     *
     *      Return: 1007 10145 121 STREET NW
     */
    public String toString() {
        StringBuilder accountAddress = new StringBuilder();

        if (suite != null)
            accountAddress.append(suite).append(" ");
        if (houseNumber != null)
            accountAddress.append(houseNumber).append(" ");
        if (streetName != null)
            accountAddress.append(streetName);

        return accountAddress.toString();
    }
}
