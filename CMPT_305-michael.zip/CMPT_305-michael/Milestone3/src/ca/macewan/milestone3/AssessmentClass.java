package ca.macewan.milestone3;

public class AssessmentClass {
    private String classOne;
    private Integer classOneP;
    private String classTwo;
    private Integer classTwoP;
    private String classThree;
    private Integer classThreeP;

    // Assessment class is denoted without 'P'
    // Assessment percentage is denoted with 'P'
    public AssessmentClass(String classOne, Integer classOneP,
                           String classTwo, Integer classTwoP,
                           String classThree, Integer classThreeP) {
        this.classOne = classOne;
        this.classOneP = classOneP;
        this.classTwo = classTwo;
        this.classTwoP = classTwoP;
        this.classThree = classThree;
        this.classThreeP = classThreeP;
    }

    // Returns class one
    public String getClassOne() {
        return classOne;
    }
    public Integer getClassOneP() {
        return classOneP;
    }

    // Returns class two
    public String getClassTwo() {
        return classTwo;
    }
    public Integer getClassTwoP() {
        return classTwoP;
    }

    // Returns class three
    public String getClassThree() {
        return classThree;
    }
    public Integer getClassThreeP() {
        return classThreeP;
    }

    /* Converts assessment classes as string:
     *      Assessment class 1: RESIDENTIAL
     *      Assessment class %1: 100%
     *      Assessment class 2: null
     *      Assessment class %2: null
     *      Assessment class 3: null
     *      Assessment class %3: null
     *
     *      Return: [RESIDENTIAL 100%]
     */
    public String toString() {
        StringBuilder accountAssessmentClass = new StringBuilder();
        accountAssessmentClass.append("[");

        if (classOne != null && classOneP != null)
            accountAssessmentClass
                    .append(classOne).append(" ")
                    .append(classOneP).append("%");
        if (classTwo != null && classTwoP != null)
            accountAssessmentClass
                    .append(", ")
                    .append(classTwo).append(" ")
                    .append(classTwoP).append("%");
        if (classThree != null && classThreeP != null)
            accountAssessmentClass
                    .append(", ")
                    .append(classThree).append(" ")
                    .append(classThreeP).append("%");

        accountAssessmentClass.append("]");
        return accountAssessmentClass.toString();
    }
}
