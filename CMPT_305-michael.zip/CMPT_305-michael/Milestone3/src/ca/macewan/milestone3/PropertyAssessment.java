package ca.macewan.milestone3;

import java.util.Locale;

public class PropertyAssessment implements Comparable<PropertyAssessment>{
    private Integer accountNumber;
    private String accountNumberString;
    private Address accountAddress;
    private String garage;
    private Neighbourhood accountNeighourhood;
    private Integer assessedValue;
    private String assessedValueString;
    private Location location;
    private AssessmentClass assessmentClass;

    public PropertyAssessment(Integer accountNumber,                                        // Account number
                              String suite, Integer houseNumber, String streetName,         // Account address
                              String garage,                                                // Garage present
                              Integer neighbourhoodID, String neighbourhood, String ward,   // Account neighbourhood
                              Integer assessedValue,                                        // Assessed value
                              Float latitude, Float longitude,                              // Account location
                              String classOne, Integer classOneP,                           // Account assessment classes
                              String classTwo, Integer classTwoP,
                              String classThree, Integer classThreeP) {
        this.accountNumber = accountNumber;
        this.accountNumberString = getAccountNumberString();

        this.accountAddress = new Address(suite, houseNumber, streetName);

        this.garage = garage;

        this.accountNeighourhood = new Neighbourhood(neighbourhoodID, neighbourhood, ward);

        this.assessedValue = assessedValue;
        this.assessedValueString = getAssessedValueString();

        this.location = new Location(latitude, longitude);

        this.assessmentClass = new AssessmentClass(classOne, classOneP,
                                                   classTwo, classTwoP,
                                                   classThree, classThreeP);
    }

    // Returns account number (as integer or string)
    public Integer getAccountNumber() {
        return accountNumber;
    }
    public String getAccountNumberString() {
        return String.format(Locale.CANADA, "%d", accountNumber);
    }

    // Returns account address
    public Address getAccountAddress() {
        return accountAddress;
    }

    // Returns garage present
    public String getGarage() {
        return garage;
    }

    // Returns account neighbourhood
    public Neighbourhood getAccountNeighbourhood() {
        return accountNeighourhood;
    }

    // Returns assessed value as integer or formatted string
    public Integer getAssessedValue() {
        return assessedValue;
    }
    public String getAssessedValueString() {
        return String.format(Locale.CANADA, "$%,d", assessedValue);
    }

    // Returns location
    public Location getLocation() {
        return location;
    }

    // Returns class assessments
    public AssessmentClass getAssessmentClass() {
        return assessmentClass;
    }

    // Possible usage to compare two properties
    public int compareTo(PropertyAssessment other) {
        return Integer.compare(this.assessedValue, other.assessedValue);
    }

    // Not necessary for MS3 possibly
    public String toString() {
        return accountNumber + " "
                + accountAddress + " "
                + assessedValue + " "
                + accountNeighourhood + " "
                + assessmentClass + "\n";
    }
}
