package ca.macewan.milestone3;

import java.util.List;
public interface PropertyAssessmentDAO {
    List<PropertyAssessment> getAllProperty();

    PropertyAssessment getByAccountNumber(Integer accountNumber);

    List<PropertyAssessment> getByNeighbourhood(String neighbourhood);

    List<PropertyAssessment> getByAssessmentClass(String assessmentClass);

    List<PropertyAssessment> getByAddress(String address);

    List<PropertyAssessment> getByRange(Integer min, Integer max);
}
