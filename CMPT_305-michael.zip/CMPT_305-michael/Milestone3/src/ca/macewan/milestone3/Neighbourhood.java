package ca.macewan.milestone3;

public class Neighbourhood {
    private Integer neighbourhoodID;
    private String neighbourhood;
    private String ward;

    public Neighbourhood(Integer neighbourhoodID, String neighbourhood, String ward) {
        this.neighbourhoodID = neighbourhoodID;
        this.neighbourhood = neighbourhood;
        this.ward = ward;
    }

    // Returns neighbourhood ID
    public Integer getNeighbourhoodID() {
        return neighbourhoodID;
    }

    // Returns neighbourhood
    public String getNeighbourhood() {
        return neighbourhood;
    }

    // Returns ward
    public String getWard() {
        return ward;
    }

    /* Converts neighbourhood as string:
     *      Neighbourhood ID: Not needed currently in string
     *      Neighbourhood: OLIVER
     *      Ward: O-day'min Ward
     *
     *      Return: OLIVER (O-day'min Ward)
     */
    public String toString() {
        StringBuilder accountNeighbourhood = new StringBuilder();

        // if (neighbourhoodID != null)
        //     accountNeighbourhood.append(neighbourhoodID);
        if (neighbourhood != null)
            accountNeighbourhood.append(neighbourhood).append(" ");
        if (ward != null)
            accountNeighbourhood.append("(").append(ward).append(")");

        return accountNeighbourhood.toString();
    }
}
