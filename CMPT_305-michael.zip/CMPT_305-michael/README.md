# CMPT_305

Used most of my code since it's split into classes (Location, Assessment Class, Address, Neighbourhood, etc)

I've gone through my code and did my best to add comments and simplify areas (delete repeated code) so it's easier to understand.
As for the MS2 tableview, I've just copied my current code into it, there's definitely improvements needed but I will work on it later.

For now, since we all have had pretty different code, I hope that you will download and review the code so far as this will be the base we will build off of.

As for how much I have completed, most of my code works except for advanced search since that was not implemented.

In PropertyAssessments.Java I have not included any calculation code as I'm unsure which data structure we would want to pass in it, this can be implemented while we continue MS3.

If there are any questions about how a portion runs, don't hesitate to ask as we are a group.

If you want to learn how the DAO functions work, just go to TestDAO.java and uncomment each block one-by-one to test, and see how it runs.

To run to Milestone2Main.java, make sure projectstructure includes the javaFX library, and when you run it, it may say some error, you have to add VM options, as you all probably know, just wanted to ensure smooth run of the main.
